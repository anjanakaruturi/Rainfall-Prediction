import numpy as np
import pandas as pd
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pickle

# Load your dataset
df = pd.read_csv('weatherAUS.csv')
rainfall_model=pickle.dump(df)

# Assuming 'raintommorow' is the column you want to predict
X = df.drop(['raintommorow', 'date', 'location'], axis=1)  # Drop irrelevant columns
y = df['raintommorow']

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train your XGBoost model
model = XGBClassifier()
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%")


# Now, you can use this trained model for predictions.
# If you have new data, you can use the same process, i.e., preprocess the data and use model.predict() to get predictions.
with open("rainfall_model", "wb") as model_file:
    pickle.dump(model, model_file) 